import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Github, Twitter, Linkedin } from "lucide-react"

export default function Footer() {
  return (
    <footer className="border-t bg-background">
      <div className="container py-8 md:py-12">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-green-600">5pringLog</h3>
            <p className="text-sm text-muted-foreground">
              Spring Framework hakkında güncel bilgiler ve pratik eğitimler sunan blog platformu.
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" asChild className="hover:text-primary hover:bg-primary/10">
                <Link href="https://github.com" target="_blank" rel="noreferrer">
                  <Github className="h-4 w-4" />
                  <span className="sr-only">GitHub</span>
                </Link>
              </Button>
              <Button variant="ghost" size="icon" asChild className="hover:text-primary hover:bg-primary/10">
                <Link href="https://twitter.com" target="_blank" rel="noreferrer">
                  <Twitter className="h-4 w-4" />
                  <span className="sr-only">Twitter</span>
                </Link>
              </Button>
              <Button variant="ghost" size="icon" asChild className="hover:text-primary hover:bg-primary/10">
                <Link href="https://linkedin.com" target="_blank" rel="noreferrer">
                  <Linkedin className="h-4 w-4" />
                  <span className="sr-only">LinkedIn</span>
                </Link>
              </Button>
            </div>
          </div>
          <div className="space-y-4">
            <h3 className="text-base font-medium">Hızlı Bağlantılar</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/" className="text-muted-foreground hover:text-primary transition-colors duration-200">
                  Ana Sayfa
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-muted-foreground hover:text-primary transition-colors duration-200">
                  Yazılar
                </Link>
              </li>
              <li>
                <Link
                  href="/spring-setup"
                  className="text-muted-foreground hover:text-primary transition-colors duration-200"
                >
                  Spring Kurulumu
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-primary transition-colors duration-200">
                  Hakkımda
                </Link>
              </li>
              <li>
                <Link
                  href="/contact"
                  className="text-muted-foreground hover:text-primary transition-colors duration-200"
                >
                  İletişim
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h3 className="text-base font-medium">Kaynaklar</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link
                  href="https://spring.io"
                  target="_blank"
                  rel="noreferrer"
                  className="text-muted-foreground hover:text-primary transition-colors duration-200"
                >
                  Spring Resmi Sitesi
                </Link>
              </li>
              <li>
                <Link
                  href="https://docs.spring.io"
                  target="_blank"
                  rel="noreferrer"
                  className="text-muted-foreground hover:text-primary transition-colors duration-200"
                >
                  Spring Dokümantasyon
                </Link>
              </li>
              <li>
                <Link
                  href="https://start.spring.io"
                  target="_blank"
                  rel="noreferrer"
                  className="text-muted-foreground hover:text-primary transition-colors duration-200"
                >
                  Spring Initializr
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h3 className="text-base font-medium">Bültene Abone Ol</h3>
            <p className="text-sm text-muted-foreground">
              Yeni yazılar ve güncellemeler hakkında bilgi almak için abone olun.
            </p>
            <div className="flex space-x-2">
              <Input type="email" placeholder="Email adresiniz" className="max-w-[220px]" />
              <Button type="submit">Abone Ol</Button>
            </div>
          </div>
        </div>
        <div className="mt-8 border-t pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} 5pringLog. Tüm hakları saklıdır.</p>
        </div>
      </div>
    </footer>
  )
}
