"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Save } from "lucide-react"

interface ArticleEditorProps {
  article?: {
    id: string
    title: string
    content: string
    excerpt: string
    status: string
  }
  onSave: (article: any) => void
  onCancel: () => void
}

export default function ArticleEditor({ article, onSave, onCancel }: ArticleEditorProps) {
  const [title, setTitle] = useState(article?.title || "")
  const [content, setContent] = useState(article?.content || "")
  const [excerpt, setExcerpt] = useState(article?.excerpt || "")
  const [status, setStatus] = useState(article?.status || "draft")

  const handleSave = () => {
    const date = new Date().toLocaleDateString("tr-TR", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })

    onSave({
      id: article?.id || Date.now().toString(),
      title,
      content,
      excerpt,
      status,
      date,
      views: article?.views || 0,
      comments: article?.comments || 0,
    })
  }

  return (
    <div className="container py-12">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="ghost" onClick={onCancel}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Geri
        </Button>
        <h1 className="text-3xl font-bold tracking-tight">{article?.id ? "Yazıyı Düzenle" : "Yeni Yazı Oluştur"}</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Yazı Bilgileri</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="title">Başlık</Label>
            <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Yazı başlığı" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="excerpt">Özet</Label>
            <Textarea
              id="excerpt"
              value={excerpt}
              onChange={(e) => setExcerpt(e.target.value)}
              placeholder="Yazının kısa özeti"
              rows={3}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="content">İçerik</Label>
            <Textarea
              id="content"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Yazının içeriği"
              rows={15}
              className="font-mono"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="status">Durum</Label>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger id="status">
                <SelectValue placeholder="Durum seçin" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="draft">Taslak</SelectItem>
                <SelectItem value="published">Yayınlandı</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={onCancel}>
            İptal
          </Button>
          <Button onClick={handleSave}>
            <Save className="mr-2 h-4 w-4" />
            Kaydet
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
