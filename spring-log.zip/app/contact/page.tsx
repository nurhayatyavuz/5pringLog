"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { Github, Linkedin, Mail, MapPin, Phone, Twitter } from "lucide-react"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    toast({
      title: "Mesajınız gönderildi",
      description: "En kısa sürede size geri dönüş yapacağız.",
    })

    setFormData({
      name: "",
      email: "",
      subject: "",
      message: "",
    })
    setIsSubmitting(false)
  }

  return (
    <div className="container py-12">
      <div className="flex flex-col items-center text-center">
        <h1 className="text-4xl font-bold tracking-tight">İletişim</h1>
        <p className="mt-4 max-w-2xl text-muted-foreground">
          Sorularınız, önerileriniz veya işbirliği teklifleriniz için benimle iletişime geçebilirsiniz.
        </p>
      </div>

      <div className="mt-12 grid gap-8 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>İletişim Bilgileri</CardTitle>
            <CardDescription>Aşağıdaki kanallardan bana ulaşabilirsiniz.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-start space-x-4">
              <Mail className="mt-1 h-5 w-5 text-muted-foreground" />
              <div>
                <h3 className="font-medium">Email</h3>
                <p className="text-sm text-muted-foreground">info@5pringlog.com</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <Phone className="mt-1 h-5 w-5 text-muted-foreground" />
              <div>
                <h3 className="font-medium">Telefon</h3>
                <p className="text-sm text-muted-foreground">+90 (000) 123 4567</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <MapPin className="mt-1 h-5 w-5 text-muted-foreground" />
              <div>
                <h3 className="font-medium">Adres</h3>
                <p className="text-sm text-muted-foreground">
                  xxxxxxx, No: 42
                  <br />
                  Ankara, Türkiye
                </p>
              </div>
            </div>

            <div className="pt-4">
              <h3 className="font-medium mb-3">Sosyal Medya</h3>
              <div className="flex space-x-4">
                <Button variant="outline" size="icon" asChild>
                  <a href="https://github.com" target="_blank" rel="noreferrer">
                    <Github className="h-4 w-4" />
                    <span className="sr-only">GitHub</span>
                  </a>
                </Button>
                <Button variant="outline" size="icon" asChild>
                  <a href="https://twitter.com" target="_blank" rel="noreferrer">
                    <Twitter className="h-4 w-4" />
                    <span className="sr-only">Twitter</span>
                  </a>
                </Button>
                <Button variant="outline" size="icon" asChild>
                  <a href="https://linkedin.com" target="_blank" rel="noreferrer">
                    <Linkedin className="h-4 w-4" />
                    <span className="sr-only">LinkedIn</span>
                  </a>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Mesaj Gönder</CardTitle>
            <CardDescription>Formu doldurarak bana mesaj gönderebilirsiniz.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Ad Soyad</Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  placeholder="Adınız ve soyadınız"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="email@example.com"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="subject">Konu</Label>
                <Input
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  placeholder="Mesajınızın konusu"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="message">Mesaj</Label>
                <Textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="Mesajınızı buraya yazın..."
                  rows={5}
                  required
                />
              </div>
              <Button type="submit" className="w-full" disabled={isSubmitting}>
                {isSubmitting ? "Gönderiliyor..." : "Gönder"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      <div className="mt-12">
        <Card>
          <CardHeader>
            <CardTitle>Sık Sorulan Sorular</CardTitle>
            <CardDescription>İşte en sık sorulan bazı sorular ve yanıtları.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="font-medium">5pringLog nedir?</h3>
              <p className="text-sm text-muted-foreground mt-1">
                5pringLog, Spring Framework ve Java ekosistemi hakkında Türkçe içerik sunan bir blog platformudur.
                Amacımız, geliştiricilere Spring teknolojilerini öğrenmeleri ve kullanmaları için kapsamlı kaynaklar
                sunmaktır.
              </p>
            </div>
            <div>
              <h3 className="font-medium">İçerik önerisinde bulunabilir miyim?</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Elbette! İçerik önerilerinizi iletişim formu aracılığıyla veya info@5pringlog.com adresine e-posta
                göndererek iletebilirsiniz. Önerileriniz bizim için çok değerli.
              </p>
            </div>
            <div>
              <h3 className="font-medium">Yazılarınızı başka platformlarda paylaşabilir miyim?</h3>
              <p className="text-sm text-muted-foreground mt-1">
                İçeriklerimizi kaynak göstererek paylaşabilirsiniz. Ancak, ticari amaçlarla kullanım için lütfen önceden
                izin alın.
              </p>
            </div>
            <div>
              <h3 className="font-medium">Özel eğitim veya danışmanlık hizmeti veriyor musunuz?</h3>
              <p className="text-sm text-muted-foreground mt-1">
                Evet, şirketlere ve bireylere özel Spring Framework eğitimleri ve danışmanlık hizmetleri sunuyoruz.
                Detaylı bilgi için lütfen iletişime geçin.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
