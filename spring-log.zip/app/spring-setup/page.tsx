import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowRight, Check, Download, ExternalLink } from "lucide-react"

export default function SpringSetupPage() {
  const steps = [
    {
      id: "step-1",
      title: "Java JDK Kurulumu",
      description: "Spring Framework için Java Development Kit (JDK) kurulumu yapın.",
      content: (
        <div className="space-y-4">
          <p>
            Spring Framework, Java platformu üzerinde çalıştığı için öncelikle Java Development Kit (JDK) kurulumu
            yapmanız gerekiyor. En az Java 8 veya daha yüksek bir sürüm önerilir, ancak en son LTS sürümünü (Java 17
            veya 21) kullanmanız tavsiye edilir.
          </p>

          <h3 className="text-lg font-medium">JDK İndirme Bağlantıları:</h3>
          <ul className="list-disc pl-6 space-y-2">
            <li>
              <a
                href="https://www.oracle.com/java/technologies/downloads/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 dark:text-blue-400 hover:underline flex items-center"
              >
                Oracle JDK
                <ExternalLink className="ml-1 h-3 w-3" />
              </a>
            </li>
            <li>
              <a
                href="https://adoptium.net/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 dark:text-blue-400 hover:underline flex items-center"
              >
                Eclipse Temurin (OpenJDK)
                <ExternalLink className="ml-1 h-3 w-3" />
              </a>
            </li>
          </ul>

          <h3 className="text-lg font-medium">Kurulum Sonrası Doğrulama:</h3>
          <p>Kurulumu doğrulamak için terminal veya komut istemcisinde aşağıdaki komutu çalıştırın:</p>
          <pre className="bg-muted p-4 rounded-md overflow-x-auto">
            <code>java -version</code>
          </pre>

          <div className="bg-green-50 dark:bg-green-950 p-4 rounded-md">
            <h4 className="flex items-center text-green-800 dark:text-green-300 font-medium">
              <Check className="mr-2 h-5 w-5" />
              İpucu
            </h4>
            <p className="text-green-700 dark:text-green-400">
              Sistem ortam değişkenlerinde JAVA_HOME değişkenini JDK kurulum dizinine ayarlamayı unutmayın.
            </p>
          </div>
        </div>
      ),
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      id: "step-2",
      title: "IDE Kurulumu",
      description: "Spring geliştirme için uygun bir IDE kurun.",
      content: (
        <div className="space-y-4">
          <p>
            Spring uygulamaları geliştirmek için entegre geliştirme ortamı (IDE) kullanmak, kod yazma verimliliğinizi
            önemli ölçüde artıracaktır. Spring için en popüler IDE'ler şunlardır:
          </p>

          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardContent className="p-4 flex flex-col items-center text-center">
                <img src="/placeholder.svg?height=80&width=80" alt="IntelliJ IDEA" className="mb-4" />
                <h3 className="font-medium">IntelliJ IDEA</h3>
                <p className="text-sm text-muted-foreground mb-4">Spring için en iyi destek ve özellikler.</p>
                <Button asChild variant="outline" size="sm">
                  <a href="https://www.jetbrains.com/idea/download/" target="_blank" rel="noopener noreferrer">
                    <Download className="mr-2 h-4 w-4" />
                    İndir
                  </a>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 flex flex-col items-center text-center">
                <img src="/placeholder.svg?height=80&width=80" alt="Eclipse" className="mb-4" />
                <h3 className="font-medium">Eclipse</h3>
                <p className="text-sm text-muted-foreground mb-4">Spring Tool Suite (STS) eklentisi ile.</p>
                <Button asChild variant="outline" size="sm">
                  <a href="https://spring.io/tools" target="_blank" rel="noopener noreferrer">
                    <Download className="mr-2 h-4 w-4" />
                    İndir
                  </a>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 flex flex-col items-center text-center">
                <img src="/placeholder.svg?height=80&width=80" alt="VS Code" className="mb-4" />
                <h3 className="font-medium">Visual Studio Code</h3>
                <p className="text-sm text-muted-foreground mb-4">Spring Boot eklentileri ile hafif bir alternatif.</p>
                <Button asChild variant="outline" size="sm">
                  <a href="https://code.visualstudio.com/download" target="_blank" rel="noopener noreferrer">
                    <Download className="mr-2 h-4 w-4" />
                    İndir
                  </a>
                </Button>
              </CardContent>
            </Card>
          </div>

          <h3 className="text-lg font-medium">Önerilen Eklentiler:</h3>
          <ul className="list-disc pl-6 space-y-1">
            <li>Spring Boot Extension Pack (VS Code)</li>
            <li>Spring Tools 4 (Eclipse)</li>
            <li>Spring Assistant (IntelliJ IDEA)</li>
          </ul>
        </div>
      ),
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      id: "step-3",
      title: "Maven veya Gradle Kurulumu",
      description: "Bağımlılık yönetimi için Maven veya Gradle kurun.",
      content: (
        <div className="space-y-4">
          <p>
            Spring projelerinde bağımlılık yönetimi ve derleme işlemleri için Maven veya Gradle kullanılır. İkisinden
            birini seçebilirsiniz:
          </p>

          <Tabs defaultValue="maven">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="maven">Maven</TabsTrigger>
              <TabsTrigger value="gradle">Gradle</TabsTrigger>
            </TabsList>
            <TabsContent value="maven" className="space-y-4 mt-4">
              <h3 className="text-lg font-medium">Maven Kurulumu:</h3>
              <ol className="list-decimal pl-6 space-y-2">
                <li>
                  <a
                    href="https://maven.apache.org/download.cgi"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 dark:text-blue-400 hover:underline flex items-center"
                  >
                    Apache Maven'ı indirin
                    <ExternalLink className="ml-1 h-3 w-3" />
                  </a>
                </li>
                <li>İndirdiğiniz arşivi açın ve istediğiniz bir konuma çıkarın</li>
                <li>Maven'ın bin dizinini PATH ortam değişkeninize ekleyin</li>
                <li>Kurulumu doğrulamak için terminal veya komut istemcisinde şu komutu çalıştırın:</li>
              </ol>
              <pre className="bg-muted p-4 rounded-md overflow-x-auto">
                <code>mvn -version</code>
              </pre>
            </TabsContent>
            <TabsContent value="gradle" className="space-y-4 mt-4">
              <h3 className="text-lg font-medium">Gradle Kurulumu:</h3>
              <ol className="list-decimal pl-6 space-y-2">
                <li>
                  <a
                    href="https://gradle.org/install/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 dark:text-blue-400 hover:underline flex items-center"
                  >
                    Gradle'ı indirin
                    <ExternalLink className="ml-1 h-3 w-3" />
                  </a>
                </li>
                <li>İndirdiğiniz arşivi açın ve istediğiniz bir konuma çıkarın</li>
                <li>Gradle'ın bin dizinini PATH ortam değişkeninize ekleyin</li>
                <li>Kurulumu doğrulamak için terminal veya komut istemcisinde şu komutu çalıştırın:</li>
              </ol>
              <pre className="bg-muted p-4 rounded-md overflow-x-auto">
                <code>gradle -version</code>
              </pre>
            </TabsContent>
          </Tabs>

          <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-md">
            <p className="text-blue-700 dark:text-blue-400">
              Not: Modern IDE'ler genellikle Maven ve Gradle'ı dahili olarak içerir, bu nedenle ayrı kurulum yapmak
              zorunda kalmayabilirsiniz.
            </p>
          </div>
        </div>
      ),
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      id: "step-4",
      title: "İlk Spring Boot Projesi",
      description: "Spring Initializr ile ilk projenizi oluşturun.",
      content: (
        <div className="space-y-4">
          <p>
            Spring Boot projesi oluşturmanın en kolay yolu Spring Initializr web aracını kullanmaktır. Bu araç, projeniz
            için gerekli tüm yapılandırmaları ve bağımlılıkları otomatik olarak oluşturur.
          </p>

          <h3 className="text-lg font-medium">Spring Initializr ile Proje Oluşturma:</h3>
          <ol className="list-decimal pl-6 space-y-3">
            <li>
              <a
                href="https://start.spring.io"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 dark:text-blue-400 hover:underline flex items-center"
              >
                Spring Initializr'ı açın
                <ExternalLink className="ml-1 h-3 w-3" />
              </a>
            </li>
            <li>
              <strong>Proje Ayarları:</strong>
              <ul className="list-disc pl-6 mt-1">
                <li>Project: Maven Project veya Gradle Project</li>
                <li>Language: Java</li>
                <li>Spring Boot: En son kararlı sürümü seçin</li>
                <li>Group: com.example (organizasyon adınız)</li>
                <li>Artifact: demo (proje adınız)</li>
                <li>Name: demo</li>
                <li>Description: Demo project for Spring Boot</li>
                <li>Package name: com.example.demo</li>
                <li>Packaging: Jar</li>
                <li>Java: 17 (veya tercih ettiğiniz sürüm)</li>
              </ul>
            </li>
            <li>
              <strong>Bağımlılıklar Ekleyin:</strong>
              <ul className="list-disc pl-6 mt-1">
                <li>Spring Web</li>
                <li>Spring Data JPA (veritabanı işlemleri için)</li>
                <li>H2 Database (geliştirme için hafif veritabanı)</li>
                <li>Spring Boot DevTools (geliştirme verimliliği için)</li>
              </ul>
            </li>
            <li>"GENERATE" düğmesine tıklayarak projeyi indirin</li>
            <li>İndirilen ZIP dosyasını açın ve IDE'nizde açın</li>
          </ol>

          <div className="bg-green-50 dark:bg-green-950 p-4 rounded-md">
            <h4 className="flex items-center text-green-800 dark:text-green-300 font-medium">
              <Check className="mr-2 h-5 w-5" />
              IDE ile Doğrudan Oluşturma
            </h4>
            <p className="text-green-700 dark:text-green-400">
              IntelliJ IDEA ve Eclipse STS gibi IDE'ler, Spring Initializr'ı doğrudan entegre eder. "New Project" &gt;
              "Spring Initializr" seçeneğini kullanabilirsiniz.
            </p>
          </div>
        </div>
      ),
      image: "/placeholder.svg?height=300&width=500",
    },
    {
      id: "step-5",
      title: "İlk Uygulamayı Çalıştırma",
      description: "Spring Boot uygulamanızı çalıştırın ve test edin.",
      content: (
        <div className="space-y-4">
          <p>
            Spring Boot projesi oluşturduktan sonra, uygulamanızı çalıştırmak ve test etmek için aşağıdaki adımları
            izleyin:
          </p>

          <h3 className="text-lg font-medium">Basit Bir REST Controller Ekleyin:</h3>
          <p>Projenizin ana paketinde yeni bir Java sınıfı oluşturun:</p>

          <pre className="bg-muted p-4 rounded-md overflow-x-auto">
            <code>{`package com.example.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @GetMapping("/hello")
    public String hello() {
        return "Merhaba, Spring Boot!";
    }
}
`}</code>
          </pre>

          <h3 className="text-lg font-medium">Uygulamayı Çalıştırma:</h3>

          <Tabs defaultValue="ide">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="ide">IDE ile</TabsTrigger>
              <TabsTrigger value="maven">Maven ile</TabsTrigger>
              <TabsTrigger value="gradle">Gradle ile</TabsTrigger>
            </TabsList>
            <TabsContent value="ide" className="space-y-2 mt-4">
              <p>IDE'nizde ana sınıfı (DemoApplication.java) bulun ve çalıştırın:</p>
              <ul className="list-disc pl-6">
                <li>IntelliJ IDEA: Sınıfa sağ tıklayın ve "Run" seçeneğini seçin</li>
                <li>Eclipse: Sınıfa sağ tıklayın ve "Run As" &gt; "Java Application" seçeneğini seçin</li>
                <li>VS Code: Sınıfı açın ve "Run" düğmesine tıklayın</li>
              </ul>
            </TabsContent>
            <TabsContent value="maven" className="space-y-2 mt-4">
              <p>Terminal veya komut istemcisinde proje dizinine gidin ve şu komutu çalıştırın:</p>
              <pre className="bg-muted p-4 rounded-md overflow-x-auto">
                <code>mvn spring-boot:run</code>
              </pre>
            </TabsContent>
            <TabsContent value="gradle" className="space-y-2 mt-4">
              <p>Terminal veya komut istemcisinde proje dizinine gidin ve şu komutu çalıştırın:</p>
              <pre className="bg-muted p-4 rounded-md overflow-x-auto">
                <code>gradle bootRun</code>
              </pre>
            </TabsContent>
          </Tabs>

          <h3 className="text-lg font-medium">Uygulamayı Test Etme:</h3>
          <p>Uygulama başlatıldıktan sonra, tarayıcınızda şu URL'yi açın:</p>
          <pre className="bg-muted p-4 rounded-md overflow-x-auto">
            <code>http://localhost:8080/hello</code>
          </pre>
          <p>Tarayıcıda "Merhaba, Spring Boot!" mesajını görmelisiniz.</p>

          <div className="bg-green-50 dark:bg-green-950 p-4 rounded-md">
            <h4 className="flex items-center text-green-800 dark:text-green-300 font-medium">
              <Check className="mr-2 h-5 w-5" />
              Tebrikler!
            </h4>
            <p className="text-green-700 dark:text-green-400">
              İlk Spring Boot uygulamanızı başarıyla oluşturdunuz ve çalıştırdınız! Artık Spring ekosistemini keşfetmeye
              ve daha karmaşık uygulamalar geliştirmeye hazırsınız.
            </p>
          </div>
        </div>
      ),
      image: "/placeholder.svg?height=300&width=500",
    },
  ]

  return (
    <div className="container py-12">
      <div className="flex flex-col items-center text-center">
        <h1 className="text-4xl font-bold tracking-tight">5 Adımda Spring Kurulumu</h1>
        <p className="mt-4 max-w-2xl text-muted-foreground">
          Spring Framework'ü hızlıca kurmak ve ilk uygulamanızı geliştirmek için adım adım rehber.
        </p>
      </div>

      <div className="mt-12 space-y-12">
        {steps.map((step, index) => (
          <div key={step.id} className="grid gap-8 md:grid-cols-2 items-center">
            <div className={`space-y-4 ${index % 2 === 1 ? "md:order-2" : ""}`}>
              <div className="inline-block rounded-lg bg-green-100 dark:bg-green-900 px-3 py-1 text-sm font-medium text-green-800 dark:text-green-300">
                Adım {index + 1}
              </div>
              <h2 className="text-3xl font-bold tracking-tight">{step.title}</h2>
              <p className="text-muted-foreground">{step.description}</p>
              {step.content}
            </div>
            <div className={index % 2 === 1 ? "md:order-1" : ""}>
              <img
                src={step.image || "/placeholder.svg"}
                alt={`Step ${index + 1}: ${step.title}`}
                className="rounded-lg border shadow-sm"
              />
            </div>
          </div>
        ))}
      </div>

      <div className="mt-16 text-center">
        <h2 className="text-2xl font-bold tracking-tight">Sonraki Adımlar</h2>
        <p className="mt-4 text-muted-foreground">
          Spring kurulumunu tamamladıktan sonra, aşağıdaki kaynaklarla öğrenmeye devam edebilirsiniz.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-4">
          <Button asChild>
            <a href="/blog">
              Blog Yazılarını İncele
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
          <Button asChild variant="outline">
            <a href="https://spring.io/guides" target="_blank" rel="noopener noreferrer">
              Resmi Spring Rehberleri
              <ExternalLink className="ml-2 h-4 w-4" />
            </a>
          </Button>
        </div>
      </div>
    </div>
  )
}
