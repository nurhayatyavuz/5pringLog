import Link from "next/link"
import { notFound } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { ArrowLeft, Calendar, Clock, MessageSquare } from "lucide-react"
import CommentSection from "@/components/comment-section"

// Mock blog post data
const blogPosts = [
  {
    id: "1",
    title: "Spring Boot ile RESTful API Geliştirme",
    content: `
# Spring Boot ile RESTful API Geliştirme

Spring Boot, modern web uygulamaları ve mikroservisler geliştirmek için popüler bir Java framework'üdür. Bu yazıda, Spring Boot kullanarak RESTful API'ler nasıl geliştirileceğini adım adım inceleyeceğiz.

## Gereksinimler

- Java 17 veya üzeri
- Maven veya Gradle
- IDE (IntelliJ IDEA, Eclipse, VS Code)

## Proje Oluşturma

Spring Initializr (https://start.spring.io/) kullanarak yeni bir Spring Boot projesi oluşturun. Aşağıdaki bağımlılıkları ekleyin:

- Spring Web
- Spring Data JPA
- H2 Database
- Lombok

## Model Sınıfı Oluşturma

İlk olarak, API'mizin işleyeceği veri modelini oluşturalım:

\`\`\`java
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String name;
    private String description;
    private BigDecimal price;
}
\`\`\`

## Repository Oluşturma

Veritabanı işlemleri için bir repository arabirimi oluşturalım:

\`\`\`java
public interface ProductRepository extends JpaRepository<Product, Long> {
}
\`\`\`

## Controller Oluşturma

RESTful endpoint'leri tanımlamak için bir controller sınıfı oluşturalım:

\`\`\`java
@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductRepository productRepository;

    public ProductController(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    @GetMapping
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Long id) {
        return productRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Product createProduct(@RequestBody Product product) {
        return productRepository.save(product);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody Product product) {
        return productRepository.findById(id)
                .map(existingProduct -> {
                    existingProduct.setName(product.getName());
                    existingProduct.setDescription(product.getDescription());
                    existingProduct.setPrice(product.getPrice());
                    return ResponseEntity.ok(productRepository.save(existingProduct));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable Long id) {
        return productRepository.findById(id)
                .map(product -> {
                    productRepository.delete(product);
                    return ResponseEntity.ok().<Void>build();
                })
                .orElse(ResponseEntity.notFound().build());
    }
}
\`\`\`

## Uygulamayı Çalıştırma

Uygulamayı çalıştırdığınızda, Spring Boot gömülü Tomcat sunucusunu başlatacak ve API'niz http://localhost:8080/api/products adresinde kullanılabilir olacaktır.

## API Testi

API'nizi test etmek için Postman veya cURL kullanabilirsiniz. Örnek bir POST isteği:

\`\`\`bash
curl -X POST http://localhost:8080/api/products \\
  -H "Content-Type: application/json" \\
  -d '{"name":"Spring Boot Kitabı","description":"Spring Boot öğrenmek için kapsamlı rehber","price":29.99}'
\`\`\`

## Sonuç

Bu temel örnek, Spring Boot ile RESTful API geliştirmenin ne kadar kolay olduğunu göstermektedir. Spring Boot, otomatik yapılandırma ve starter bağımlılıkları sayesinde geliştirme sürecini önemli ölçüde basitleştirir.

Daha gelişmiş API'ler için şunları ekleyebilirsiniz:
- Spring Security ile kimlik doğrulama
- Swagger ile API dokümantasyonu
- Veri doğrulama
- Hata işleme
- Sayfalama ve sıralama
    `,
    date: "10 Mayıs 2024",
    readTime: "8 dk",
    author: {
      name: "Ahmet Yılmaz",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    category: "API Development",
    slug: "spring-boot-restful-api",
    commentCount: 5,
  },
  {
    id: "2",
    title: "Spring Security ile Kimlik Doğrulama",
    content: "Spring Security ile kimlik doğrulama içeriği...",
    date: "5 Mayıs 2024",
    readTime: "10 dk",
    author: {
      name: "Mehmet Kaya",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    category: "Security",
    slug: "spring-security-authentication",
    commentCount: 3,
  },
]

export default function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = blogPosts.find((post) => post.slug === params.slug)

  if (!post) {
    notFound()
  }

  return (
    <div className="container py-12">
      <div className="mx-auto max-w-3xl">
        <Button asChild variant="ghost" className="mb-6">
          <Link href="/blog">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Tüm Yazılar
          </Link>
        </Button>

        <div>
          <div className="mb-2 text-sm text-muted-foreground">{post.category}</div>
          <h1 className="text-4xl font-bold tracking-tight">{post.title}</h1>

          <div className="mt-4 flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Avatar className="h-8 w-8">
                <AvatarImage src={post.author.avatar || "/placeholder.svg"} alt={post.author.name} />
                <AvatarFallback>{post.author.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <span className="text-sm font-medium">{post.author.name}</span>
            </div>
            <Separator orientation="vertical" className="h-4" />
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <Calendar className="h-4 w-4" />
              <span>{post.date}</span>
            </div>
            <Separator orientation="vertical" className="h-4" />
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <Clock className="h-4 w-4" />
              <span>{post.readTime}</span>
            </div>
            <Separator orientation="vertical" className="h-4" />
            <div className="flex items-center gap-1 text-sm text-muted-foreground">
              <MessageSquare className="h-4 w-4" />
              <span>{post.commentCount} yorum</span>
            </div>
          </div>
        </div>

        <Separator className="my-8" />

        <div className="prose prose-green dark:prose-invert max-w-none">
          {post.content.split("\n").map((line, index) => (
            <p key={index}>{line}</p>
          ))}
        </div>

        <Separator className="my-8" />

        <CommentSection postId={post.id} />
      </div>
    </div>
  )
}
