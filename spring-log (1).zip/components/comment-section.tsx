"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAuth } from "@/lib/auth-context"
import { MessageSquare } from "lucide-react"

// Mock comments data
const initialComments = [
  {
    id: "1",
    author: {
      name: "Ayşe Demir",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content: "Harika bir yazı olmuş, özellikle controller kısmındaki örnekler çok açıklayıcı. Teşekkürler!",
    date: "11 Mayıs 2024",
  },
  {
    id: "2",
    author: {
      name: "Burak Yılmaz",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    content: "Spring Boot ile API geliştirmeye yeni başladım ve bu yazı tam ihtiyacım olan şeydi. Devamını bekliyorum.",
    date: "12 Mayıs 2024",
  },
]

export default function CommentSection({ postId }: { postId: string }) {
  const { user } = useAuth()
  const [comments, setComments] = useState(initialComments)
  const [newComment, setNewComment] = useState("")

  const handleSubmitComment = () => {
    if (!newComment.trim()) return

    const comment = {
      id: Date.now().toString(),
      author: {
        name: user?.name || "Misafir",
        avatar: "/placeholder.svg?height=40&width=40",
      },
      content: newComment,
      date: new Date().toLocaleDateString("tr-TR"),
    }

    setComments([...comments, comment])
    setNewComment("")
  }

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
        <MessageSquare className="h-5 w-5" />
        Yorumlar ({comments.length})
      </h2>

      {user ? (
        <div className="mb-8">
          <Textarea
            placeholder="Yorumunuzu yazın..."
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            className="mb-4"
            rows={4}
          />
          <Button onClick={handleSubmitComment}>Yorum Yap</Button>
        </div>
      ) : (
        <div className="mb-8 p-4 bg-muted rounded-lg text-center">
          <p className="mb-4">Yorum yapmak için giriş yapmalısınız.</p>
          <Button asChild>
            <a href="/auth/login">Giriş Yap</a>
          </Button>
        </div>
      )}

      <div className="space-y-6">
        {comments.map((comment) => (
          <div key={comment.id} className="p-4 border rounded-lg">
            <div className="flex items-center gap-3 mb-3">
              <Avatar className="h-8 w-8">
                <AvatarImage src={comment.author.avatar || "/placeholder.svg"} alt={comment.author.name} />
                <AvatarFallback>{comment.author.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <div className="font-medium">{comment.author.name}</div>
                <div className="text-xs text-muted-foreground">{comment.date}</div>
              </div>
            </div>
            <p className="text-sm">{comment.content}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
