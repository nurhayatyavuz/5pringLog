import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { ArrowRight, Github, Linkedin, Mail, Twitter } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="container py-12">
      <div className="mx-auto max-w-3xl">
        <div className="flex flex-col items-center text-center">
          <Avatar className="h-24 w-24">
            <AvatarImage src="/placeholder.svg?height=96&width=96" alt="Ahmet Yılmaz" />
            <AvatarFallback>AY</AvatarFallback>
          </Avatar>
          <h1 className="mt-6 text-4xl font-bold tracking-tight">Hakkımda</h1>
          <div className="mt-4 flex space-x-4">
            <Button variant="ghost" size="icon" asChild>
              <a href="https://github.com" target="_blank" rel="noreferrer">
                <Github className="h-5 w-5" />
                <span className="sr-only">GitHub</span>
              </a>
            </Button>
            <Button variant="ghost" size="icon" asChild>
              <a href="https://twitter.com" target="_blank" rel="noreferrer">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </a>
            </Button>
            <Button variant="ghost" size="icon" asChild>
              <a href="https://linkedin.com" target="_blank" rel="noreferrer">
                <Linkedin className="h-5 w-5" />
                <span className="sr-only">LinkedIn</span>
              </a>
            </Button>
            <Button variant="ghost" size="icon" asChild>
              <a href="mailto:info@5pringlog.com">
                <Mail className="h-5 w-5" />
                <span className="sr-only">Email</span>
              </a>
            </Button>
          </div>
        </div>

        <Separator className="my-8" />

        <div className="space-y-6">
          <h2 className="text-2xl font-bold tracking-tight">Merhaba, ben Ahmet Yılmaz!</h2>
          <p>
            Ben bir yazılım geliştirici ve eğitimciyim. 10 yılı aşkın süredir Java ekosisteminde çalışıyorum ve son 7
            yıldır Spring Framework üzerine yoğunlaşmış durumdayım.
          </p>
          <p>
            Kariyerim boyunca finans, e-ticaret ve telekomünikasyon sektörlerinde çeşitli projelerde görev aldım. Bu
            süreçte edindiğim deneyimleri ve bilgileri paylaşmak amacıyla 5pringLog'u kurdum.
          </p>
          <p>
            5pringLog, Spring Framework ve Java ekosistemi hakkında bilgi edinmek isteyen geliştiricilere yönelik
            kapsamlı bir kaynak olmayı hedefliyor. Burada Spring Boot, Spring Security, Spring Data ve diğer Spring
            modülleri hakkında pratik rehberler, öğreticiler ve en iyi uygulamaları bulabilirsiniz.
          </p>

          <h2 className="text-2xl font-bold tracking-tight">Uzmanlık Alanlarım</h2>
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardContent className="p-4">
                <h3 className="font-bold">Spring Framework</h3>
                <p className="text-sm text-muted-foreground">
                  Spring Core, Spring Boot, Spring MVC, Spring Security, Spring Data JPA
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <h3 className="font-bold">Mikroservis Mimarisi</h3>
                <p className="text-sm text-muted-foreground">Spring Cloud, Docker, Kubernetes, API Gateway</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <h3 className="font-bold">Veritabanı Teknolojileri</h3>
                <p className="text-sm text-muted-foreground">PostgreSQL, MySQL, MongoDB, Redis</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <h3 className="font-bold">DevOps</h3>
                <p className="text-sm text-muted-foreground">CI/CD, Jenkins, GitHub Actions, AWS</p>
              </CardContent>
            </Card>
          </div>

          <h2 className="text-2xl font-bold tracking-tight">Eğitim ve Sertifikalar</h2>
          <ul className="space-y-4">
            <li className="flex items-start">
              <div className="mr-4 mt-1 flex h-8 w-8 items-center justify-center rounded-full bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-graduation-cap"
                >
                  <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
                  <path d="M6 12v5c0 2 2 3 6 3s6-1 6-3v-5" />
                </svg>
              </div>
              <div>
                <h3 className="font-bold">Bilgisayar Mühendisliği, XYZ Üniversitesi</h3>
                <p className="text-sm text-muted-foreground">2010 - 2014</p>
              </div>
            </li>
            <li className="flex items-start">
              <div className="mr-4 mt-1 flex h-8 w-8 items-center justify-center rounded-full bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-award"
                >
                  <circle cx="12" cy="8" r="6" />
                  <path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11" />
                </svg>
              </div>
              <div>
                <h3 className="font-bold">Oracle Certified Professional, Java SE 11 Developer</h3>
                <p className="text-sm text-muted-foreground">2020</p>
              </div>
            </li>
            <li className="flex items-start">
              <div className="mr-4 mt-1 flex h-8 w-8 items-center justify-center rounded-full bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-award"
                >
                  <circle cx="12" cy="8" r="6" />
                  <path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11" />
                </svg>
              </div>
              <div>
                <h3 className="font-bold">Pivotal Certified Spring Professional</h3>
                <p className="text-sm text-muted-foreground">2019</p>
              </div>
            </li>
          </ul>

          <h2 className="text-2xl font-bold tracking-tight">5pringLog Hakkında</h2>
          <p>
            5pringLog, 2022 yılında Spring Framework ve Java ekosistemi hakkında kaliteli Türkçe içerik sağlamak
            amacıyla kuruldu. Amacımız, Türkiye'deki ve Türkçe konuşulan diğer ülkelerdeki geliştiricilere Spring
            Framework'ü öğrenmeleri ve kullanmaları için kapsamlı bir kaynak sunmaktır.
          </p>
          <p>
            Sitemizde düzenli olarak yeni içerikler yayınlıyor, güncel Spring sürümleri hakkında bilgiler paylaşıyor ve
            okuyucularımızın sorularını yanıtlıyoruz. Ayrıca, Spring ile ilgili webinarlar ve eğitimler düzenliyoruz.
          </p>

          <div className="flex justify-center mt-8">
            <Button asChild>
              <a href="/contact">
                Benimle İletişime Geçin
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
