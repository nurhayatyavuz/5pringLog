import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ArrowRight, Search } from "lucide-react"

// Mock blog posts data
const blogPosts = [
  {
    id: "1",
    title: "Spring Boot ile RESTful API Geliştirme",
    excerpt: "Spring Boot kullanarak modern ve ölçeklenebilir RESTful API'ler nasıl geliştirilir?",
    date: "10 Mayıs 2024",
    category: "API Development",
    slug: "spring-boot-restful-api",
  },
  {
    id: "2",
    title: "Spring Security ile Kimlik Doğrulama",
    excerpt: "Spring Security kullanarak uygulamanızda güvenli kimlik doğrulama nasıl sağlanır?",
    date: "5 Mayıs 2024",
    category: "Security",
    slug: "spring-security-authentication",
  },
  {
    id: "3",
    title: "Spring Data JPA ile Veritabanı İşlemleri",
    excerpt: "Spring Data JPA ile veritabanı işlemlerini kolaylaştırın ve kod tekrarını azaltın.",
    date: "1 Mayıs 2024",
    category: "Database",
    slug: "spring-data-jpa",
  },
  {
    id: "4",
    title: "Spring Cloud ile Mikroservis Mimarisi",
    excerpt: "Spring Cloud kullanarak ölçeklenebilir ve dayanıklı mikroservis mimarileri nasıl oluşturulur?",
    date: "25 Nisan 2024",
    category: "Microservices",
    slug: "spring-cloud-microservices",
  },
  {
    id: "5",
    title: "Spring WebFlux ile Reaktif Programlama",
    excerpt: "Spring WebFlux ile reaktif, non-blocking web uygulamaları geliştirmeyi öğrenin.",
    date: "20 Nisan 2024",
    category: "Reactive Programming",
    slug: "spring-webflux-reactive",
  },
  {
    id: "6",
    title: "Spring Boot Actuator ile Uygulama İzleme",
    excerpt: "Spring Boot Actuator kullanarak uygulamanızın sağlık durumunu ve metriklerini nasıl izlersiniz?",
    date: "15 Nisan 2024",
    category: "Monitoring",
    slug: "spring-boot-actuator",
  },
]

export default function BlogPage() {
  return (
    <div className="container py-12">
      <div className="flex flex-col items-center text-center">
        <h1 className="text-4xl font-bold tracking-tight">Blog Yazıları</h1>
        <p className="mt-4 max-w-2xl text-muted-foreground">
          Spring Framework ile ilgili en güncel yazılar, rehberler ve öğreticiler.
        </p>
      </div>

      {/* Search */}
      <div className="mt-8 flex justify-center">
        <div className="relative w-full max-w-lg">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input type="search" placeholder="Yazılarda ara..." className="pl-10" />
        </div>
      </div>

      {/* Blog Posts */}
      <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {blogPosts.map((post) => (
          <Card key={post.id} className="flex flex-col card-hover">
            <CardHeader>
              <div className="text-sm text-muted-foreground">{post.category}</div>
              <CardTitle className="mt-2">{post.title}</CardTitle>
              <CardDescription>{post.date}</CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <p>{post.excerpt}</p>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" className="w-full button-hover">
                <Link href={`/blog/${post.slug}`}>
                  Devamını Oku
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {/* Pagination */}
      <div className="mt-12 flex justify-center">
        <div className="flex space-x-2">
          <Button variant="outline" disabled>
            Önceki
          </Button>
          <Button variant="outline">1</Button>
          <Button variant="outline">2</Button>
          <Button variant="outline">3</Button>
          <Button variant="outline">Sonraki</Button>
        </div>
      </div>
    </div>
  )
}
