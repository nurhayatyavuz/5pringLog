"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/lib/auth-context"
import { BookOpen, MessageSquare, ThumbsUp, User } from "lucide-react"

export default function DashboardPage() {
  const { user } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!user) {
      router.push("/auth/login")
    } else if (user.role === "admin") {
      router.push("/admin")
    }
  }, [user, router])

  if (!user) {
    return null
  }

  return (
    <div className="container py-12">
      <div className="flex flex-col">
        <h1 className="text-3xl font-bold tracking-tight">Kullanıcı Paneli</h1>
        <p className="text-muted-foreground">
          Hoş geldiniz, {user.name}! Hesabınızı ve aktivitelerinizi buradan yönetebilirsiniz.
        </p>
      </div>

      <div className="mt-8">
        <Tabs defaultValue="profile">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="profile">Profil</TabsTrigger>
            <TabsTrigger value="comments">Yorumlarım</TabsTrigger>
            <TabsTrigger value="favorites">Favorilerim</TabsTrigger>
          </TabsList>
          <TabsContent value="profile" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Profil Bilgileri</CardTitle>
                <CardDescription>Kişisel bilgilerinizi görüntüleyin ve güncelleyin.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
                    <User className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium">{user.name}</h3>
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <h4 className="mb-2 text-sm font-medium">Hesap Bilgileri</h4>
                    <Card>
                      <CardContent className="p-4">
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-sm text-muted-foreground">Üyelik Tipi</span>
                            <span className="text-sm font-medium">Standart</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-muted-foreground">Katılım Tarihi</span>
                            <span className="text-sm font-medium">1 Mayıs 2024</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-muted-foreground">Son Giriş</span>
                            <span className="text-sm font-medium">Bugün</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                  <div>
                    <h4 className="mb-2 text-sm font-medium">İstatistikler</h4>
                    <Card>
                      <CardContent className="p-4">
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-sm text-muted-foreground">Okunan Yazılar</span>
                            <span className="text-sm font-medium">12</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-muted-foreground">Yorumlar</span>
                            <span className="text-sm font-medium">5</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-muted-foreground">Beğeniler</span>
                            <span className="text-sm font-medium">8</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>

                <div className="flex flex-col gap-4">
                  <h4 className="text-sm font-medium">Hesap Ayarları</h4>
                  <div className="grid gap-4 md:grid-cols-2">
                    <Button variant="outline">Profili Düzenle</Button>
                    <Button variant="outline">Şifre Değiştir</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="comments" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Yorumlarım</CardTitle>
                <CardDescription>Yazılara yaptığınız yorumları görüntüleyin ve yönetin.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <MessageSquare className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">Spring Boot ile RESTful API Geliştirme</span>
                      </div>
                      <span className="text-xs text-muted-foreground">12 Mayıs 2024</span>
                    </div>
                    <p className="mt-2 text-sm">
                      Harika bir yazı olmuş, özellikle controller kısmındaki örnekler çok açıklayıcı. Teşekkürler!
                    </p>
                    <div className="mt-2 flex justify-end gap-2">
                      <Button variant="ghost" size="sm">
                        Düzenle
                      </Button>
                      <Button variant="ghost" size="sm">
                        Sil
                      </Button>
                    </div>
                  </div>
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <MessageSquare className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">Spring Security ile Kimlik Doğrulama</span>
                      </div>
                      <span className="text-xs text-muted-foreground">8 Mayıs 2024</span>
                    </div>
                    <p className="mt-2 text-sm">
                      OAuth2 ile ilgili daha detaylı bir yazı yazabilir misiniz? Bu konuda zorlanıyorum.
                    </p>
                    <div className="mt-2 flex justify-end gap-2">
                      <Button variant="ghost" size="sm">
                        Düzenle
                      </Button>
                      <Button variant="ghost" size="sm">
                        Sil
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="favorites" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Favori Yazılarım</CardTitle>
                <CardDescription>Beğendiğiniz ve kaydettiğiniz yazıları görüntüleyin.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <BookOpen className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">Spring Boot ile RESTful API Geliştirme</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <ThumbsUp className="h-4 w-4 text-green-600" />
                        <Button variant="ghost" size="sm">
                          Kaldır
                        </Button>
                      </div>
                    </div>
                    <p className="mt-2 text-sm text-muted-foreground">
                      Spring Boot kullanarak modern ve ölçeklenebilir RESTful API'ler nasıl geliştirilir?
                    </p>
                  </div>
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <BookOpen className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">Spring Data JPA ile Veritabanı İşlemleri</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <ThumbsUp className="h-4 w-4 text-green-600" />
                        <Button variant="ghost" size="sm">
                          Kaldır
                        </Button>
                      </div>
                    </div>
                    <p className="mt-2 text-sm text-muted-foreground">
                      Spring Data JPA ile veritabanı işlemlerini kolaylaştırın ve kod tekrarını azaltın.
                    </p>
                  </div>
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <BookOpen className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">Spring Boot Actuator ile Uygulama İzleme</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <ThumbsUp className="h-4 w-4 text-green-600" />
                        <Button variant="ghost" size="sm">
                          Kaldır
                        </Button>
                      </div>
                    </div>
                    <p className="mt-2 text-sm text-muted-foreground">
                      Spring Boot Actuator kullanarak uygulamanızın sağlık durumunu ve metriklerini nasıl izlersiniz?
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
