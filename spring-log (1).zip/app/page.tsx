import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, BookOpen, Code, FileText, Users } from "lucide-react"

export default function Home() {
  const featuredPosts = [
    {
      id: "1",
      title: "Spring Boot ile RESTful API Geliştirme",
      excerpt: "Spring Boot kullanarak modern ve ölçeklenebilir RESTful API'ler nasıl geliştirilir?",
      date: "10 Mayıs 2024",
      slug: "spring-boot-restful-api",
    },
    {
      id: "2",
      title: "Spring Security ile Kimlik Doğrulama",
      excerpt: "Spring Security kullanarak uygulamanızda güvenli kimlik doğrulama nasıl sağlanır?",
      date: "5 Mayıs 2024",
      slug: "spring-security-authentication",
    },
    {
      id: "3",
      title: "Spring Data JPA ile Veritabanı İşlemleri",
      excerpt: "Spring Data JPA ile veritabanı işlemlerini kolaylaştırın ve kod tekrarını azaltın.",
      date: "1 Mayıs 2024",
      slug: "spring-data-jpa",
    },
  ]

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-b from-green-50 to-white dark:from-green-950 dark:to-background py-16 md:py-24">
        <div className="container flex flex-col items-center text-center">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
            <span className="text-green-600 dark:text-green-500">5pring</span>Log
          </h1>
          <p className="mt-6 max-w-2xl text-lg text-muted-foreground">
            Spring Framework hakkında güncel bilgiler, pratik eğitimler ve detaylı rehberler sunan blog platformu.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Button asChild size="lg">
              <Link href="/blog">
                Yazıları Keşfet
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link href="/spring-setup">Spring Kurulumu</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Featured Posts */}
      <section className="py-16">
        <div className="container">
          <div className="flex flex-col items-center text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Öne Çıkan Yazılar</h2>
            <p className="mt-4 max-w-2xl text-muted-foreground">
              Spring Framework ile ilgili en güncel ve popüler yazılarımız.
            </p>
          </div>
          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {featuredPosts.map((post) => (
              <Card key={post.id} className="flex flex-col card-hover">
                <CardHeader>
                  <CardTitle>{post.title}</CardTitle>
                  <CardDescription>{post.date}</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <p>{post.excerpt}</p>
                </CardContent>
                <CardFooter>
                  <Button asChild variant="outline" className="w-full button-hover">
                    <Link href={`/blog/${post.slug}`}>
                      Devamını Oku
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
          <div className="mt-12 flex justify-center">
            <Button asChild variant="outline">
              <Link href="/blog">Tüm Yazıları Gör</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-muted py-16">
        <div className="container">
          <div className="flex flex-col items-center text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Neler Sunuyoruz?</h2>
            <p className="mt-4 max-w-2xl text-muted-foreground">
              5pringLog ile Spring Framework öğrenmenin ve kullanmanın avantajları.
            </p>
          </div>
          <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            <Card className="bg-background card-hover">
              <CardHeader className="flex flex-row items-center gap-4">
                <BookOpen className="h-8 w-8 text-green-600" />
                <CardTitle>Kapsamlı Rehberler</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Spring Framework'ün tüm modülleri için detaylı ve anlaşılır rehberler.
                </p>
              </CardContent>
            </Card>
            <Card className="bg-background card-hover">
              <CardHeader className="flex flex-row items-center gap-4">
                <Code className="h-8 w-8 text-green-600" />
                <CardTitle>Pratik Örnekler</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">Gerçek dünya senaryolarına dayalı kod örnekleri ve projeler.</p>
              </CardContent>
            </Card>
            <Card className="bg-background card-hover">
              <CardHeader className="flex flex-row items-center gap-4">
                <FileText className="h-8 w-8 text-green-600" />
                <CardTitle>Güncel İçerik</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Spring ekosistemindeki en son gelişmeler ve güncellemeler hakkında bilgiler.
                </p>
              </CardContent>
            </Card>
            <Card className="bg-background card-hover">
              <CardHeader className="flex flex-row items-center gap-4">
                <Users className="h-8 w-8 text-green-600" />
                <CardTitle>Topluluk Desteği</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">Yorumlar ve üyelik sistemi ile aktif bir öğrenme topluluğu.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Why Spring Section */}
      <section className="py-16 bg-muted">
        <div className="container">
          <div className="flex flex-col items-center text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Neden Spring Framework?</h2>
            <p className="mt-4 max-w-2xl text-muted-foreground">
              Spring Framework, Java tabanlı kurumsal uygulamalar geliştirmek için en popüler ve güçlü çözümdür.
            </p>
          </div>

          <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            <div className="flex flex-col items-center text-center p-6 rounded-lg bg-background card-hover">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-layers"
                >
                  <path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z" />
                  <path d="m22 12-8.6 3.91a2 2 0 0 1-1.66 0L3.1 12" />
                  <path d="m22 17-8.6 3.91a2 2 0 0 1-1.66 0L3.1 17" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Modüler Yapı</h3>
              <p className="text-muted-foreground">
                Spring'in modüler yapısı sayesinde, ihtiyacınız olan bileşenleri seçerek uygulamanızı
                oluşturabilirsiniz. Bu, daha hafif ve özelleştirilebilir uygulamalar geliştirmenizi sağlar.
              </p>
            </div>

            <div className="flex flex-col items-center text-center p-6 rounded-lg bg-background card-hover">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-zap"
                >
                  <path d="M13 2H9l-3 12h4l-1 8 9-14h-5l2-6z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Hızlı Geliştirme</h3>
              <p className="text-muted-foreground">
                Spring Boot ile dakikalar içinde çalışan bir uygulama oluşturabilirsiniz. Otomatik yapılandırma ve
                starter bağımlılıkları sayesinde geliştirme süreci önemli ölçüde hızlanır.
              </p>
            </div>

            <div className="flex flex-col items-center text-center p-6 rounded-lg bg-background card-hover">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-shield"
                >
                  <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Güvenlik</h3>
              <p className="text-muted-foreground">
                Spring Security, uygulamanızı güvende tutmak için kapsamlı güvenlik özellikleri sunar. Kimlik doğrulama,
                yetkilendirme ve yaygın güvenlik tehditlerine karşı koruma sağlar.
              </p>
            </div>

            <div className="flex flex-col items-center text-center p-6 rounded-lg bg-background card-hover">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-database"
                >
                  <ellipse cx="12" cy="5" rx="9" ry="3" />
                  <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
                  <path d="M3 12c0 1.66 4 3 9 3s9-1.34 9-3" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Veritabanı Entegrasyonu</h3>
              <p className="text-muted-foreground">
                Spring Data, veritabanı işlemlerini basitleştirir ve kod tekrarını azaltır. JPA, JDBC, MongoDB, Redis ve
                daha birçok veritabanı teknolojisi ile sorunsuz çalışır.
              </p>
            </div>

            <div className="flex flex-col items-center text-center p-6 rounded-lg bg-background card-hover">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-network"
                >
                  <rect x="16" y="16" width="6" height="6" rx="1" />
                  <rect x="2" y="16" width="6" height="6" rx="1" />
                  <rect x="9" y="2" width="6" height="6" rx="1" />
                  <path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3" />
                  <path d="M12 12V8" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Mikroservis Desteği</h3>
              <p className="text-muted-foreground">
                Spring Cloud, mikroservis mimarileri oluşturmak için kapsamlı araçlar sunar. Servis keşfi, yapılandırma
                yönetimi, yük dengeleme ve daha fazlası için hazır çözümler sağlar.
              </p>
            </div>

            <div className="flex flex-col items-center text-center p-6 rounded-lg bg-background card-hover">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 mb-4">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="lucide lucide-users"
                >
                  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                  <circle cx="9" cy="7" r="4" />
                  <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                  <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                </svg>
              </div>
              <h3 className="text-xl font-bold mb-2">Geniş Topluluk</h3>
              <p className="text-muted-foreground">
                Spring, dünya çapında milyonlarca geliştirici tarafından kullanılan ve desteklenen bir çerçevedir. Geniş
                topluluk desteği, sorunlarınıza hızlı çözümler bulmanızı sağlar.
              </p>
            </div>
          </div>

          <div className="mt-12 text-center">
            <p className="text-lg max-w-3xl mx-auto mb-6">
              Spring Framework, kurumsal Java uygulamaları geliştirmek için endüstri standardı haline gelmiştir. Büyük
              şirketlerden startuplara kadar birçok organizasyon, uygulamalarını geliştirmek için Spring'i tercih
              ediyor.
            </p>
            <Button asChild size="lg" className="button-hover">
              <Link href="/spring-setup">
                Spring ile Başlayın
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="rounded-lg bg-green-50 dark:bg-green-950 p-8 md:p-12 text-center">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Spring Kurulumunu 5 Adımda Öğrenin</h2>
            <p className="mt-4 max-w-2xl mx-auto text-muted-foreground">
              Adım adım görsellerle desteklenmiş Spring kurulum rehberimiz ile hızlıca başlayın.
            </p>
            <Button asChild size="lg" className="mt-8">
              <Link href="/spring-setup">
                Kurulum Rehberini Görüntüle
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
