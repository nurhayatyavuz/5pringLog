"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAuth } from "@/lib/auth-context"
import { BarChart, BookOpen, Edit, FileText, MessageSquare, Plus, Trash, Users } from "lucide-react"
import ArticleEditor from "@/components/article-editor"

// Mock articles data
const initialArticles = [
  {
    id: "1",
    title: "Spring Boot ile RESTful API Geliştirme",
    excerpt: "Spring Boot kullanarak modern ve ölçeklenebilir RESTful API'ler nasıl geliştirilir?",
    date: "10 Mayıs 2024",
    status: "published",
    views: 245,
    comments: 5,
  },
  {
    id: "2",
    title: "Spring Security ile Kimlik Doğrulama",
    excerpt: "Spring Security kullanarak uygulamanızda güvenli kimlik doğrulama nasıl sağlanır?",
    date: "5 Mayıs 2024",
    status: "published",
    views: 187,
    comments: 3,
  },
  {
    id: "3",
    title: "Spring Data JPA ile Veritabanı İşlemleri",
    excerpt: "Spring Data JPA ile veritabanı işlemlerini kolaylaştırın ve kod tekrarını azaltın.",
    date: "1 Mayıs 2024",
    status: "published",
    views: 156,
    comments: 2,
  },
  {
    id: "4",
    title: "Spring WebFlux ile Reaktif Programlama",
    excerpt: "Spring WebFlux ile reaktif, non-blocking web uygulamaları geliştirmeyi öğrenin.",
    date: "20 Nisan 2024",
    status: "draft",
    views: 0,
    comments: 0,
  },
]

// Mock users data
const users = [
  {
    id: "1",
    name: "Ahmet Yılmaz",
    email: "admin@example.com",
    role: "admin",
    joinDate: "1 Ocak 2024",
    lastLogin: "Bugün",
    comments: 8,
  },
  {
    id: "2",
    name: "Mehmet Kaya",
    email: "user@example.com",
    role: "user",
    joinDate: "15 Ocak 2024",
    lastLogin: "Dün",
    comments: 12,
  },
  {
    id: "3",
    name: "Ayşe Demir",
    email: "ayse@example.com",
    role: "user",
    joinDate: "5 Şubat 2024",
    lastLogin: "3 gün önce",
    comments: 5,
  },
]

// Mock comments data
const comments = [
  {
    id: "1",
    author: "Mehmet Kaya",
    content: "Harika bir yazı olmuş, özellikle controller kısmındaki örnekler çok açıklayıcı. Teşekkürler!",
    date: "11 Mayıs 2024",
    articleTitle: "Spring Boot ile RESTful API Geliştirme",
    status: "approved",
  },
  {
    id: "2",
    author: "Ayşe Demir",
    content: "Spring Boot ile API geliştirmeye yeni başladım ve bu yazı tam ihtiyacım olan şeydi. Devamını bekliyorum.",
    date: "12 Mayıs 2024",
    articleTitle: "Spring Boot ile RESTful API Geliştirme",
    status: "approved",
  },
  {
    id: "3",
    author: "Ali Yıldız",
    content: "OAuth2 ile ilgili daha detaylı bir yazı yazabilir misiniz? Bu konuda zorlanıyorum.",
    date: "8 Mayıs 2024",
    articleTitle: "Spring Security ile Kimlik Doğrulama",
    status: "pending",
  },
]

export default function AdminPage() {
  const { user } = useAuth()
  const router = useRouter()
  const [articles, setArticles] = useState(initialArticles)
  const [isEditing, setIsEditing] = useState(false)
  const [currentArticle, setCurrentArticle] = useState<any>(null)

  useEffect(() => {
    if (!user) {
      router.push("/auth/login")
    } else if (user.role !== "admin") {
      router.push("/dashboard")
    }
  }, [user, router])

  if (!user || user.role !== "admin") {
    return null
  }

  const handleCreateArticle = () => {
    setCurrentArticle({
      id: Date.now().toString(),
      title: "",
      content: "",
      excerpt: "",
      status: "draft",
    })
    setIsEditing(true)
  }

  const handleEditArticle = (article: any) => {
    setCurrentArticle(article)
    setIsEditing(true)
  }

  const handleDeleteArticle = (id: string) => {
    setArticles(articles.filter((article) => article.id !== id))
  }

  const handleSaveArticle = (article: any) => {
    if (articles.find((a) => a.id === article.id)) {
      setArticles(articles.map((a) => (a.id === article.id ? article : a)))
    } else {
      setArticles([...articles, article])
    }
    setIsEditing(false)
    setCurrentArticle(null)
  }

  if (isEditing) {
    return <ArticleEditor article={currentArticle} onSave={handleSaveArticle} onCancel={() => setIsEditing(false)} />
  }

  return (
    <div className="container py-12">
      <div className="flex flex-col">
        <h1 className="text-3xl font-bold tracking-tight">Admin Paneli</h1>
        <p className="text-muted-foreground">Hoş geldiniz, {user.name}! Sitenizi buradan yönetebilirsiniz.</p>
      </div>

      <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-100 dark:bg-green-900">
                <FileText className="h-6 w-6 text-green-700 dark:text-green-300" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Toplam Yazı</p>
                <h3 className="text-2xl font-bold">{articles.length}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900">
                <Users className="h-6 w-6 text-blue-700 dark:text-blue-300" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Kullanıcılar</p>
                <h3 className="text-2xl font-bold">{users.length}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-purple-100 dark:bg-purple-900">
                <MessageSquare className="h-6 w-6 text-purple-700 dark:text-purple-300" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Yorumlar</p>
                <h3 className="text-2xl font-bold">{comments.length}</h3>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-orange-100 dark:bg-orange-900">
                <BarChart className="h-6 w-6 text-orange-700 dark:text-orange-300" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Toplam Görüntülenme</p>
                <h3 className="text-2xl font-bold">588</h3>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-8">
        <Tabs defaultValue="articles">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="articles">Yazılar</TabsTrigger>
            <TabsTrigger value="users">Kullanıcılar</TabsTrigger>
            <TabsTrigger value="comments">Yorumlar</TabsTrigger>
          </TabsList>
          <TabsContent value="articles" className="mt-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Yazılar</CardTitle>
                  <CardDescription>Tüm yazıları yönetin, düzenleyin veya yenilerini ekleyin.</CardDescription>
                </div>
                <Button onClick={handleCreateArticle}>
                  <Plus className="mr-2 h-4 w-4" />
                  Yeni Yazı
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {articles.map((article) => (
                    <div key={article.id} className="rounded-lg border p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <BookOpen className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">{article.title}</span>
                            {article.status === "draft" && (
                              <span className="rounded-full bg-yellow-100 px-2 py-0.5 text-xs text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300">
                                Taslak
                              </span>
                            )}
                          </div>
                          <p className="mt-1 text-sm text-muted-foreground">{article.excerpt}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="icon" onClick={() => handleEditArticle(article)}>
                            <Edit className="h-4 w-4" />
                            <span className="sr-only">Düzenle</span>
                          </Button>
                          <Button variant="ghost" size="icon" onClick={() => handleDeleteArticle(article.id)}>
                            <Trash className="h-4 w-4" />
                            <span className="sr-only">Sil</span>
                          </Button>
                        </div>
                      </div>
                      <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                        <div>{article.date}</div>
                        <div>{article.views} görüntülenme</div>
                        <div>{article.comments} yorum</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="users" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Kullanıcılar</CardTitle>
                <CardDescription>Kayıtlı kullanıcıları görüntüleyin ve yönetin.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {users.map((user) => (
                    <div key={user.id} className="rounded-lg border p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <Users className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">{user.name}</span>
                            <span
                              className={`rounded-full px-2 py-0.5 text-xs ${
                                user.role === "admin"
                                  ? "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300"
                                  : "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
                              }`}
                            >
                              {user.role === "admin" ? "Admin" : "Kullanıcı"}
                            </span>
                          </div>
                          <p className="mt-1 text-sm text-muted-foreground">{user.email}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="ghost" size="sm">
                            Düzenle
                          </Button>
                        </div>
                      </div>
                      <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                        <div>Katılım: {user.joinDate}</div>
                        <div>Son giriş: {user.lastLogin}</div>
                        <div>{user.comments} yorum</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="comments" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Yorumlar</CardTitle>
                <CardDescription>Kullanıcı yorumlarını görüntüleyin, onaylayın veya silin.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {comments.map((comment) => (
                    <div key={comment.id} className="rounded-lg border p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <MessageSquare className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{comment.author}</span>
                          <span
                            className={`rounded-full px-2 py-0.5 text-xs ${
                              comment.status === "approved"
                                ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
                                : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
                            }`}
                          >
                            {comment.status === "approved" ? "Onaylandı" : "Beklemede"}
                          </span>
                        </div>
                        <span className="text-xs text-muted-foreground">{comment.date}</span>
                      </div>
                      <p className="mt-2 text-sm">{comment.content}</p>
                      <div className="mt-2 text-xs text-muted-foreground">Yazı: {comment.articleTitle}</div>
                      <div className="mt-2 flex justify-end gap-2">
                        {comment.status === "pending" && (
                          <Button variant="outline" size="sm">
                            Onayla
                          </Button>
                        )}
                        <Button variant="ghost" size="sm">
                          Sil
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
